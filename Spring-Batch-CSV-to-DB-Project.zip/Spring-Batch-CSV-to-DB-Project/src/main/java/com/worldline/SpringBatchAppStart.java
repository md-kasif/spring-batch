/**
 * @author debpaul
 *
 */

package com.worldline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchAppStart {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchAppStart.class, args);
	}
}
